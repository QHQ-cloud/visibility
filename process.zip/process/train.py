import torch
import config
import os
import torch.nn.functional as F
from torch.optim import Adam
from tqdm import tqdm
import numpy as np
from resnet import ResNet18  # 导入模型
from build_dataset import train_loader  # 导入训练数据
import pickle
from matplotlib import pyplot as plt
import torch.nn as nn
model = ResNet18().to(config.device)

optimizer = Adam(model.parameters(),lr = config.lr_rating)  # 平滑的优化器
model.load_state_dict(torch.load(os.path.join(config.model_path,'model80.pkl')))
loss_list = []
num = 0
def train(epoch):
    for i in range(epoch):
        bar = tqdm(train_loader,total=len(train_loader),ascii=True)
        for idx,(input_,target) in enumerate(bar):
            input_ = input_.to(config.device)
            target = target.to(config.device)
            optimizer.zero_grad()
            y_hat = model(input_) #[batch_Size,category]  # 在我们pytorch里面有一点好处 就是代码会自己进行one_hot 编码
            loss = F.cross_entropy(y_hat,target)
            #[-1,vocab_size]  [-1] 自动one_hot 编码
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(),0.1)
            optimizer.step()
            loss_list.append(loss.item())
            bar.set_description("epoch:{} idx:{} loss:{:.6f}".format(i,idx,np.mean(loss_list)))

        if i % 9 == 0:
            torch.save(model.state_dict(),"./model/model{}.pkl".format(i))
            torch.save(optimizer.state_dict(),"./model/optimizer{}.pkl".format(i))
# 那个functional 也在nn 下 以后不要用nn.tanh()

train(200)