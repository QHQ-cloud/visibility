"""完成测试"""
import torch
import config
from resnet import ResNet18
from build_dataset import test_loader,val_data,train_data,train_loader
import os
import torch.nn.functional as F
from tqdm import tqdm
def eval():
    model = ResNet18().to(config.device)
    model.load_state_dict(torch.load(os.path.join(config.model_path,'model99.pkl')))

    eval_acc = 0.
    loss_train = 0.
    eval_acc_train = 0.
    for batch_x, batch_y in tqdm(test_loader,ascii = True):
        batch_x = batch_x.to(config.device)
        batch_y = batch_y.to(config.device)
        y_hat_test = model(batch_x)  # [32,22]
        loss = F.cross_entropy(y_hat_test,batch_y)
        loss += loss.item()
        pred = torch.max(y_hat_test, 1)[1]  # 不仅得到具体的值 还会得到索引
        num_correct = (pred == batch_y).sum()
        # print(num_correct)
        # print(num_correct.item())
        eval_acc += num_correct.item()


    # for batch_x_train, batch_y_train in tqdm(train_loader,ascii = True):
    #     batch_x_train = batch_x_train.to(config.device)
    #     batch_y_train = batch_y_train.to(config.device)
    #     y_hat_train = model(batch_x_train)  # [32,22]
    #     loss_train = F.cross_entropy(y_hat_train, batch_y_train)
    #     loss_train += loss_train.item()
    #     pred_train = torch.max(y_hat_train, 1)[1]  # 不仅得到具体的值 还会得到索引
    #     num_correct_train = (pred_train == batch_y_train).sum()
    #     eval_acc_train += num_correct_train.item()


    print('Test Loss:{:.6f},Acc: {:.6f}'.format(loss / (len(val_data)),eval_acc / (len(val_data))))
    # print('Train Loss:{:.6f},Acc: {:.6f}'.format(loss_train / (len(train_data)),eval_acc_train / (len(train_data))))
eval()